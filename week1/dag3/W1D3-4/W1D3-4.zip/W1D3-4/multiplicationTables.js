for (i = 0; i <= 10; i++) {
  let uitkomst = i * 9;
  console.log(i + " * 9 = " + uitkomst);
}
