console.log("Hello Winc Academy");

let name = "Patrick";
console.log(name);

// 2 variabelen (numbers) optellen
let number1 = 2;
let number2 = 4;
console.log(number1 + number2);

// 2 variabelen (strings) optellen

let voornaam = "Patrick";
let achternaam = " Brouwer";
console.log(voornaam + achternaam);

// Nog wat sommetjes met operators
let vermenigvuldigen = number2 - number1;
console.log(vermenigvuldigen);

let delen = number2 * number1;
console.log(delen);

let modulus = number1 % +number2;
console.log(modulus);

// variabele leeftijd in cijfers log met typeof
let leeftijd = 42;
console.log(typeof leeftijd);

leeftijd = "heel oud";
console.log(typeof leeftijd);
